CREATE TABLE Quejas(
    id INT AUTO_INCREMENT PRIMARY KEY ,
    Nombre VARCHAR (50),
    Apellido VARCHAR (50),
    Ubicacion VARCHAR (20),
    Decripcion VARCHAR (100)

);